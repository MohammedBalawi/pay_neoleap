// server.js (JSON + AES, Neoleap)

require("dotenv").config();

const express = require("express");
const bodyParser = require("body-parser");
const CryptoJS = require("crypto-js");
const axios = require("axios");

// إعدادات Express
const app = express();
app.use(bodyParser.json());

const PORT = process.env.PORT || 3000;

// =========================
// متغيرات من ملف .env (نفس الأسماء اللي عندك)
// =========================
const TRANSPORTAL_ID =
  process.env.TRANSPORTAL_ID || "904zXK3D0cIHkuj";

const TRANSPORTAL_PASSWORD =
  process.env.TRANSPORTAL_PASSWORD || "iO!Qwu5d#P9$87R";

const RESOURCE_KEY =
  process.env.RESOURCE_KEY ||
  "52993662231652993662231652993662";

// روابط النجاح والفشل
// في .env خليهم مثلا:
// SUCCESS_URL=http://localhost:3000/neoleap/success
// ERROR_URL=http://localhost:3000/neoleap/error
const SUCCESS_URL =
  process.env.SUCCESS_URL || "http://localhost:3000/neoleap/success";

const ERROR_URL =
  process.env.ERROR_URL || "http://localhost:3000/neoleap/error";

// رابط الـ hosted من Neoleap
const HOSTED_PAYMENT_URL =
  process.env.HOSTED_PAYMENT_URL ||
  "https://securepayments.neoleap.com.sa/pg/payment/hosted.htm";

// IV الثابت من ال SDK
const AES_IV = "PGKEYENCDECIVSPC";

// =========================
// دوال مساعدة
// =========================

// دالة توليد trackId عشوائي
function generateTrackId(length = 10) {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

// دالة التشفير AES CBC PKCS7 مثل الـ SDK
function encryptTrandata(jsonString) {
  const key = CryptoJS.enc.Utf8.parse(RESOURCE_KEY);
  const iv = CryptoJS.enc.Utf8.parse(AES_IV);

  const encrypted = CryptoJS.AES.encrypt(jsonString, key, {
    iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });

  // نرجع الـ cipherText بصيغة HEX
  return encrypted.ciphertext.toString(CryptoJS.enc.Hex);
}

// =========================
// Endpoint يستدعيه تطبيق Flutter لعمل الدفع
// =========================
app.post("/neoleap/create-payment", async (req, res) => {
  try {
    const amountNumber = Number(req.body.amount || 1);
    const amount = amountNumber.toFixed(2);
    const trackId = generateTrackId();

    // JSON الأصلي قبل التشفير (نفس مثال الإيميل)
    const plainObject = {
      id: TRANSPORTAL_ID,
      password: TRANSPORTAL_PASSWORD,
      action: "1",
      currencyCode: "682",
      errorURL: ERROR_URL,
      responseURL: SUCCESS_URL,
      trackId: trackId,
      amt: amount,
    };

    const plainJsonArray = JSON.stringify([plainObject]);

    console.log("===== NEOLEAP DEBUG =====");
    console.log("PLAIN JSON:", plainJsonArray);

    const trandata = encryptTrandata(plainJsonArray);
    console.log("TRANDATA:", trandata);
    console.log("=========================");

    // جسم الطلب اللي بنرسله للبوابة
    const requestBody = [
      {
        id: TRANSPORTAL_ID,
        trandata: trandata,
        errorURL: ERROR_URL,
        responseURL: SUCCESS_URL,
      },
    ];

    let bankResponse;
    try {
      bankResponse = await axios.post(
        HOSTED_PAYMENT_URL,
        JSON.stringify(requestBody),
        {
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          timeout: 20000,
        }
      );
    } catch (error) {
      console.error("Neoleap error:", error);
      return res.status(500).json({
        message: "Error communicating with Neoleap",
        raw:
          error.response && error.response.data
            ? error.response.data
            : String(error),
      });
    }

    console.log("BANK RAW RESPONSE:", bankResponse.data);

    const data = bankResponse.data;
    let paymentUrl = null;

    // شكل الرد المتوقع:
    // [ { result: "6002...:https://....", status: "1" } ]
    if (Array.isArray(data) && data.length > 0 && data[0].result) {
  const resultStr = data[0].result;
const parts = resultStr.split(":");
const paymentId = parts[0];
let baseUrl = parts.slice(1).join(":").trim(); // احتياط لو فيه ":" في الرابط

// لو الـ URL ما فيه PaymentID / paymentId نضيفها يدويًا
if (!/paymentid=/i.test(baseUrl)) {
  const separator = baseUrl.includes("?") ? "&" : "?";
  baseUrl = `${baseUrl}${separator}PaymentID=${paymentId}`;
}

console.log("paymentId:", paymentId);
console.log("redirectUrl (final):", baseUrl);

paymentUrl = baseUrl;

    }

    return res.json({
      url: paymentUrl,
      raw: data,
    });
  } catch (err) {
    console.error("Server error:", err);
    return res.status(500).json({
      message: "Internal server error",
      error: String(err),
    });
  }
});

// =========================
// صفحات النجاح والفشل (عشان الـ SUCCESS_URL / ERROR_URL)
// =========================

// ✅ صفحة نجاح الدفع
app.get("/neoleap/success", (req, res) => {
  console.log("✅ Neoleap redirect to SUCCESS page:", req.query);
  res.send(`
    <html>
      <head><title>Payment Success</title></head>
      <body>
        <h1>تمت عملية الدفع بنجاح ✅</h1>
        <p>يمكنك الآن إغلاق هذه الصفحة والرجوع للتطبيق.</p>
      </body>
    </html>
  `);
});

// ❌ صفحة فشل الدفع
app.get("/neoleap/error", (req, res) => {
  console.log("❌ Neoleap redirect to ERROR page:", req.query);
  res.status(400).send(`
    <html>
      <head><title>Payment Failed</title></head>
      <body>
        <h1>فشلت عملية الدفع ❌</h1>
        <p>الرجاء المحاولة مرة أخرى.</p>
      </body>
    </html>
  `);
});

// =========================
// تشغيل السيرفر
// =========================
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
